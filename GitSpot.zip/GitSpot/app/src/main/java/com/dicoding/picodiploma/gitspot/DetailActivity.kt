package com.dicoding.picodiploma.gitspot

import androidx.appcompat.app.AppCompatActivity


class DetailActivity : AppCompatActivity() {

}