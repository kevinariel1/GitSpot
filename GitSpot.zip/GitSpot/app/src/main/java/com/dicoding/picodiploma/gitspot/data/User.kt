package com.dicoding.picodiploma.gitspot.data

data class User(
    val id: Int,
    val login: String,
    val avatarUrl: String
)
